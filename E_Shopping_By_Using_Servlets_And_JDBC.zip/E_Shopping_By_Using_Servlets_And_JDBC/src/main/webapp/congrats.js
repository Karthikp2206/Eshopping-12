const confettiCanvas = document.getElementById("confettiCanvas");
const ctx = confettiCanvas.getContext("2d");
const replayButton = document.getElementById("replayButton");

confettiCanvas.width = window.innerWidth;
confettiCanvas.height = window.innerHeight;

let confetti = [];
const colors = ["#ff3d3d", "#ffd700", "#00fa9a", "#1e90ff", "#ff69b4"];

class Confetti {
  constructor() {
    this.x = Math.random() * confettiCanvas.width;
    this.y = Math.random() * confettiCanvas.height - confettiCanvas.height;
    this.size = Math.random() * 10 + 5;
    this.speed = Math.random() * 3 + 2;
    this.color = colors[Math.floor(Math.random() * colors.length)];
    this.opacity = Math.random() * 0.8 + 0.2;
  }

  draw() {
    ctx.globalAlpha = this.opacity;
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
    ctx.fillStyle = this.color;
    ctx.fill();
  }

  update() {
    this.y += this.speed;
    if (this.y > confettiCanvas.height) {
      this.y = -this.size;
      this.x = Math.random() * confettiCanvas.width;
    }
  }
}

function createConfetti() {
  for (let i = 0; i < 100; i++) {
    confetti.push(new Confetti());
  }
}

function animateConfetti() {
  ctx.clearRect(0, 0, confettiCanvas.width, confettiCanvas.height);
  confetti.forEach((confetto) => {
    confetto.update();
    confetto.draw();
  });
  requestAnimationFrame(animateConfetti);
}

replayButton.addEventListener("click", () => {
  confetti = [];
  createConfetti();
});

createConfetti();
animateConfetti();
