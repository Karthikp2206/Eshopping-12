package com.eshopping.controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.eshopping.DAO.CartDAO;
import com.eshopping.DAO.CartDAOImpl;
import com.eshopping.DAO.CustomerDAO;
import com.eshopping.DAO.CustomerDAOImpl;
import com.eshopping.DAO.ProductDAO;
import com.eshopping.DAO.ProductDAOImpl;
import com.eshopping.model.CustomerDetails;
import com.eshopping.model.ProductDetails;
@WebServlet("/customerLogin")
public class CustomerLogin extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String emailid = request.getParameter("emailid");
		String password = request.getParameter("password");	
		
		CustomerDAO customerDAO = new CustomerDAOImpl();
		CartDAO cartDAO = new CartDAOImpl();
		ProductDAO productDAO = new ProductDAOImpl();
		CustomerDetails customerDetails = customerDAO.getCustomerDetailsByUsingEmailAndPassword(emailid, password);
		List<ProductDetails> allProductDetails = productDAO.getAllProductDetails();
		// To Get Cart Count
		int count = cartDAO.getCustomerCartCount(customerDetails.getId());
		PrintWriter writer = response.getWriter();
		response.setContentType("text/html");
		HttpSession session = request.getSession();
		if(customerDetails!=null)
		{
			session.setAttribute("logincustomerdetails",customerDetails);
			//Cart Count Adding In To The Session
			session.setAttribute("cartcount", count);
			session.setAttribute("AllProductDetails", allProductDetails);
			RequestDispatcher dispatcher = request.getRequestDispatcher("AllProductDetailsForCustomer.jsp");
			dispatcher.forward(request, response);
		}
		else
		{
			RequestDispatcher dispatcher = request.getRequestDispatcher("CustomerLogin.html");
			dispatcher.include(request, response);
			writer.println("<center><h3>Invalid Emailid And Password</h3></center>");
		}
	}
}
