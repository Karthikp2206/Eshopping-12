package com.eshopping.controller;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.eshopping.DAO.CartDAO;
import com.eshopping.DAO.CartDAOImpl;
import com.eshopping.model.Cart;
@WebServlet("/addToCart")
public class AddToCart extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String tempproid = request.getParameter("productid");
		int productid = Integer.parseInt(tempproid);
		String tempcustid = request.getParameter("customerid");
		int customerid = Integer.parseInt(tempcustid);
		Cart cart = new Cart();
		cart.setCustomerid(customerid);
		cart.setProductid(productid);
		CartDAO cartDAO = new CartDAOImpl();
		int customerCartCount = cartDAO.getCustomerCartCount(customerid);
		if(cartDAO.insertCartDetails(cart)>0)
		{
			request.getSession().setAttribute("cartcount", customerCartCount);
			RequestDispatcher dispatcher = request.getRequestDispatcher("AllProductDetailsForCustomer.jsp");
			dispatcher.forward(request, response);
		}
		else
		{
			RequestDispatcher dispatcher = request.getRequestDispatcher("AllProductDetailsForCustomer.jsp");
			dispatcher.forward(request, response);
		}
	}
}
