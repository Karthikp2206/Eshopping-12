package com.eshopping.controller;
import java.io.IOException; 
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.eshopping.DAO.CustomerDAO;
import com.eshopping.DAO.CustomerDAOImpl;
import com.eshopping.exception.CustomerException;
import com.eshopping.model.CustomerDetails;
import com.eshopping.service.CustomerService;
import com.eshopping.service.CustomerServiceImpl;
@WebServlet("/customerRegistration")
public class CustomerRegistration extends HttpServlet
{
	protected void doGet(HttpServletRequest request, HttpServletResponse response)throws ServletException,IOException
	{
		String name = request.getParameter("name");
		String emailid = request.getParameter("emailid");
		String tempmobilenumber = request.getParameter("mobilenumber");
		long mobilenumber = Long.parseLong(tempmobilenumber);
		String password = request.getParameter("password");
		String gender = request.getParameter("gender");
		String address = request.getParameter("address");
		
		CustomerDetails customerDetails = new CustomerDetails();
		customerDetails.setName(name);
		customerDetails.setEmailid(emailid);
		customerDetails.setMobilenumber(mobilenumber);
		customerDetails.setPassword(password);
		customerDetails.setGender(gender);
		customerDetails.setAddress(address);
		
		CustomerService customerService = new CustomerServiceImpl();
		PrintWriter writer = response.getWriter();
		response.setContentType("text/html");
		try
		{
			if(customerService.userRegistration(customerDetails))
			{
				RequestDispatcher dispatcher = request.getRequestDispatcher("CustomerLogin.html");
				dispatcher.forward(request, response);
			}
			else
			{
				RequestDispatcher dispatcher = request.getRequestDispatcher("CustomerRegistration.html");
				dispatcher.include(request, response);
				writer.println("Invalid Data");
			}
		}
		catch(CustomerException e)
		{
			RequestDispatcher dispatcher = request.getRequestDispatcher("CustomerRegistration.html");
			dispatcher.include(request, response);
			writer.println("<center><h5>"+e.getGetExceptionMsg()+"</h5></center>");
		}
	}
}
