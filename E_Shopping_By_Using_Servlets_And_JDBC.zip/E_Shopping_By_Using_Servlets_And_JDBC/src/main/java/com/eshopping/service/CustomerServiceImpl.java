package com.eshopping.service;
import java.util.List;
import com.eshopping.DAO.CustomerDAO;
import com.eshopping.DAO.CustomerDAOImpl;
import com.eshopping.exception.CustomerException;
import com.eshopping.model.CustomerDetails;
public class CustomerServiceImpl implements CustomerService
{
	CustomerDAO customerDAO = new CustomerDAOImpl();
	public boolean userRegistration(CustomerDetails customerDetails)
	{
		List<CustomerDetails> allCustomerDetails = customerDAO.getAllCustomerDetails();
		boolean emailidmatch = allCustomerDetails.stream()
				.anyMatch((customer -> customer.getEmailid()
						.equalsIgnoreCase(customerDetails.getEmailid())));
		if(emailidmatch)
		{
			throw new CustomerException("Emailid Already Existed");
		}
		boolean mobilenumbermatch = allCustomerDetails.stream()
				.anyMatch((customer -> customer.getMobilenumber()==customerDetails
				.getMobilenumber()));
		if(mobilenumbermatch)
		{
			throw new CustomerException("Mobile Number Already Existed");
		}
		boolean passwordmatch = allCustomerDetails.stream()
				.anyMatch((customer -> customer.getPassword()
						.equals(customerDetails.getPassword())));
		if(passwordmatch)
		{
			throw new CustomerException("Password Already Existed");
		}
		if(customerDAO.insertCustomerDetails(customerDetails)>0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
