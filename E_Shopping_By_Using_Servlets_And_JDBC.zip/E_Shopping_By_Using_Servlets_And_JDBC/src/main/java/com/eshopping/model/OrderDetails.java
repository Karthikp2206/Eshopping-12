package com.eshopping.model;
import java.sql.Date;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class OrderDetails 
{
	private int order_id;
	private int customer_id;
	private int product_id;
	private int purchase_quantity;
	private Date purchase_date; 
	private double total_purchase_price;
}
