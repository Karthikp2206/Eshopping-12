package com.eshopping.model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
//@Setter
//@Getter
//@ToString
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProductDetails 
{
	private int id;
	private String name;
	private String brand;
	private double price;
	private double discount;
	private String category;
	private int quantity;
}
