package com.eshopping.model;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Cart
{
	private int cartid;
	private int customerid;
	private int productid;
}
