package com.eshopping.DAO;
import com.eshopping.model.Cart;
public interface CartDAO 
{
	int getCustomerCartCount(int customerid);
	int insertCartDetails(Cart cart);
}
