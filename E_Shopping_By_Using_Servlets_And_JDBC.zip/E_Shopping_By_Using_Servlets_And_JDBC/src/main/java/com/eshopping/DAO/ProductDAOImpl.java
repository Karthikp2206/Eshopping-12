package com.eshopping.DAO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.eshopping.model.ProductDetails;
public class ProductDAOImpl implements ProductDAO
{
	private static final String url="jdbc:mysql://localhost:3306/teca63_e_shopping?user=root&password=V@mshi0066";
	private static final String insert="insert into product_details(Name, Brand, Price, Discount, Category, Quantity)values(?,?,?,?,?,?)";
	private static final String select_All="select * from product_details";
	public int insertProductDetails(ProductDetails productDetails) 
	{
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connection = DriverManager.getConnection(url);
			PreparedStatement preparedStatement = connection.prepareStatement(insert);
			preparedStatement.setString(1,productDetails.getName());
			preparedStatement.setString(2,productDetails.getBrand());
			preparedStatement.setDouble(3,productDetails.getPrice());
			preparedStatement.setDouble(4,productDetails.getDiscount());
			preparedStatement.setString(5,productDetails.getCategory());
			preparedStatement.setInt(6,productDetails.getQuantity());
			return preparedStatement.executeUpdate();
		}
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
			return 0;
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			return 0;
		}
	}
	public List<ProductDetails> getAllProductDetails() 
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connection = DriverManager.getConnection(url);
			PreparedStatement preparedStatement = connection.prepareStatement(select_All);
			ResultSet resultSet = preparedStatement.executeQuery();
			List<ProductDetails>allProductDetails = new ArrayList<ProductDetails>();
			if(resultSet.isBeforeFirst())
			{
				while(resultSet.next())
				{
					ProductDetails productDetails = new ProductDetails();
					productDetails.setId(resultSet.getInt("Id"));
					productDetails.setName(resultSet.getString("Name"));
					productDetails.setBrand(resultSet.getString("Brand"));
					productDetails.setPrice(resultSet.getDouble("Price"));
					productDetails.setDiscount(resultSet.getDouble("Discount"));
					productDetails.setCategory(resultSet.getString("Category"));
					productDetails.setQuantity(resultSet.getInt("Quantity"));
					allProductDetails.add(productDetails);				
				}
				return allProductDetails;
			}
		} 
		catch (ClassNotFoundException e)
		{
			e.printStackTrace();
			return null;
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
			return null;
		}
		return null;
	}
}
