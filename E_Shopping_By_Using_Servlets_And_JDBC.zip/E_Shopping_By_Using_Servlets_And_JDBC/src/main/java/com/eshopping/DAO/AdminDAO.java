package com.eshopping.DAO;

public interface AdminDAO 
{
	boolean AdminLogin(String emailid,String password);
}