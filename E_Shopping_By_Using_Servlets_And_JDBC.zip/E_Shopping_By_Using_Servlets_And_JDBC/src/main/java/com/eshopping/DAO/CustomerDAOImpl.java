package com.eshopping.DAO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.eshopping.model.CustomerDetails;
public class CustomerDAOImpl implements CustomerDAO
{
	private static final String url="jdbc:mysql://localhost:3306/teca63_e_shopping?user=root&password=V@mshi0066";
	private static final String insert="insert into customer_details(Name, Emailid, Password,"
			+"Mobile_Number,Gender, Address)values(?,?,?,?,?,?)";
	private static final String select_all="select * from customer_details";
	private static final String select_customer="select * from customer_details where Emailid=? and Password=?";
	public int insertCustomerDetails(CustomerDetails customerDetails) 
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connection =DriverManager.getConnection(url);
			PreparedStatement preparedStatement =connection.prepareStatement(insert);
			preparedStatement.setString(1,customerDetails.getName());
			preparedStatement.setString(2,customerDetails.getEmailid());
			preparedStatement.setString(3,customerDetails.getPassword());
			preparedStatement.setLong(4,customerDetails.getMobilenumber());
			preparedStatement.setString(5, customerDetails.getGender());
			preparedStatement.setString(6, customerDetails.getAddress());
			return preparedStatement.executeUpdate();
		}
	    catch (ClassNotFoundException e)
	    {
			e.printStackTrace();
			return 0;
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			return 0;
		}
	}
	public List<CustomerDetails> getAllCustomerDetails() 
	{
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connection = DriverManager.getConnection(url);
			PreparedStatement preparedStatement = connection.prepareStatement(select_all);
			ResultSet resultSet = preparedStatement.executeQuery();
			List<CustomerDetails> list = new ArrayList<CustomerDetails>();
			if(resultSet.isBeforeFirst())
			{
				while(resultSet.next())
				{
					CustomerDetails customerDetails = new CustomerDetails();
					customerDetails.setEmailid(resultSet.getString("Emailid"));
					customerDetails.setMobilenumber(resultSet.getLong("Mobile_Number"));
					customerDetails.setPassword(resultSet.getString("Password"));
					list.add(customerDetails);
				}
				return list;
			}
			else
			{
				return null;
			}
		} 
		catch (ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}
	@Override
	public CustomerDetails getCustomerDetailsByUsingEmailAndPassword(String emailid, String Password) 
	{
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connection = DriverManager.getConnection(url);
			PreparedStatement preparedStatement = connection.prepareStatement(select_customer);
			preparedStatement.setString(1, emailid);
			preparedStatement.setString(2, Password);
			ResultSet resultSet = preparedStatement.executeQuery();
			if(resultSet.next())
			{
				CustomerDetails customerDetails = new CustomerDetails();
				customerDetails.setEmailid(resultSet.getString("Emailid"));
				customerDetails.setMobilenumber(resultSet.getLong("Mobile_Number"));
				customerDetails.setName(resultSet.getString("name"));
				return customerDetails;
			}
			else
			{
				return null;
			}
		} 
		catch (ClassNotFoundException e)
		{
			e.printStackTrace();
			return null;
		}
		catch (SQLException e)
		{
			e.printStackTrace();
			return null;
		}
		
	}
}
