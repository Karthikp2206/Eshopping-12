package com.eshopping.DAO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.eshopping.model.Cart;
import java.sql.ResultSetMetaData;
public class CartDAOImpl implements CartDAO
{
	private static final String url="jdbc:mysql://localhost:3306/teca63_e_shopping?user=root&password=V@mshi0066";
	private static final String count_of_Customer_Id="select count(Customer_Id) from cart where Customer_Id=?";
	private static final String insert_cart="insert into cart(Customer_Id, Product_Id)values(?,?)";
	@Override
	public int getCustomerCartCount(int customerid)
	{
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connection = DriverManager.getConnection(url);
			PreparedStatement preparedStatement = connection.prepareStatement(count_of_Customer_Id);
			preparedStatement.setInt(1, customerid);
			ResultSet resultSet =  preparedStatement.executeQuery();
			if(resultSet.next())
			{
				ResultSetMetaData metaData = resultSet.getMetaData();
				int columnCount = metaData.getColumnCount();
				System.out.println("Column Count in Buffer Memory :"+ columnCount);
				System.out.println("Column Name in Buffer Memory :"+ metaData.getColumnLabel(1));
				return resultSet.getInt(1);
			}
			else
			{
				return 0;
			}
		}
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
			return 0;
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
			return 0;
		}
	}
	@Override
	public int insertCartDetails(Cart cart)
	{
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connection = DriverManager.getConnection(url);
			PreparedStatement preparedStatement = connection.prepareStatement(insert_cart);
			preparedStatement.setInt(1,cart.getCustomerid());
			preparedStatement.setInt(2,cart.getProductid());
			return preparedStatement.executeUpdate();
		}
		catch (ClassNotFoundException e) 
		{
			e.printStackTrace();
			return 0;
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
			return 0;
		}
	}
}